import { motion } from 'motion/react';
import { useInView } from 'motion/react';
import { useRef } from 'react';
import { Droplets, Sparkles, UtensilsCrossed, Factory } from 'lucide-react';

export function Products() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });

  const products = [
    {
      icon: Droplets,
      name: "Washing Machine Liquid",
      benefits: [
        "Deep stain removal",
        "Low foam, fabric-safe",
        "For front load & top load"
      ],
      color: "from-blue-500 to-cyan-500"
    },
    {
      icon: Sparkles,
      name: "Body Soap",
      benefits: [
        "Long-lasting freshness",
        "Gentle on skin",
        "For daily shower use"
      ],
      color: "from-green-500 to-emerald-500"
    },
    {
      icon: UtensilsCrossed,
      name: "Dishwash Liquid",
      benefits: [
        "Powerful grease cutting",
        "Gentle on hands",
        "Pleasant fragrance"
      ],
      color: "from-orange-500 to-amber-500"
    },
    {
      icon: Factory,
      name: "Industrial Cleaning Liquid",
      benefits: [
        "Heavy-duty cleaning",
        "For factories & hotels",
        "Commercial strength"
      ],
      color: "from-purple-500 to-indigo-500"
    }
  ];

  return (
    <section id="products" ref={ref} className="py-20 bg-gradient-to-br from-gray-50 to-blue-50">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl sm:text-5xl mb-6">Our Products</h2>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Complete cleaning solutions for every need
          </p>
        </motion.div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          {products.map((product, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 30 }}
              animate={isInView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              className="group relative bg-white rounded-2xl overflow-hidden hover:shadow-2xl transition-all duration-300 transform hover:-translate-y-2"
            >
              <div className={`absolute top-0 left-0 right-0 h-2 bg-gradient-to-r ${product.color}`} />
              
              <div className="p-6">
                <div className={`w-16 h-16 bg-gradient-to-br ${product.color} rounded-2xl flex items-center justify-center mb-6 transform group-hover:scale-110 transition-transform duration-300`}>
                  <product.icon className="w-8 h-8 text-white" />
                </div>

                <h3 className="text-xl mb-4">{product.name}</h3>

                <ul className="space-y-2">
                  {product.benefits.map((benefit, idx) => (
                    <li key={idx} className="flex items-start gap-2 text-gray-600">
                      <div className="w-1.5 h-1.5 bg-blue-600 rounded-full mt-2 flex-shrink-0" />
                      <span>{benefit}</span>
                    </li>
                  ))}
                </ul>
              </div>

              <div className={`absolute bottom-0 left-0 right-0 h-1 bg-gradient-to-r ${product.color} transform scale-x-0 group-hover:scale-x-100 transition-transform duration-300`} />
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}