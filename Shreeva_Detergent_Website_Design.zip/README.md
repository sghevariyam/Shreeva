
  # Shreeva Detergent Website Design

  This is a code bundle for Shreeva Detergent Website Design. The original project is available at https://www.figma.com/design/bZk5Py4hEm731K4gQER3ve/Shreeva-Detergent-Website-Design.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  